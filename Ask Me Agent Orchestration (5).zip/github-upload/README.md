# Schedule and Alert — Ask Me

Interactive prototype for the Lumenore **Ask Me** agent orchestration experience — conversational creation of schedules and alerts, with an editable evidence panel and an Automation Hub.

## View it

Open `index.html` in any browser (no build step, works offline).

**GitHub Pages:** Settings → Pages → Source: *Deploy from a branch* → Branch: `main` / `/ (root)` → Save.
Live URL: `https://<user>.github.io/<repo>/`

## Contents

- `index.html` — self-contained prototype (HTML + inlined JS/CSS/fonts)
- `.nojekyll` — tells Pages to serve files as-is

## Flows included

- Schedule creation via chat questions (occurrence → date range → time) with Skip and step counts
- Alert creation with conditions, groups, AND/OR, filters and occurrence
- Editable right-side evidence panel (prompt, schedule, output, sharing, next run)
- Automation Hub: pause / resume / edit / delete
